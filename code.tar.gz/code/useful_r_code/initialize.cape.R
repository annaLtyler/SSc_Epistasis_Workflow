#This function takes a phenotype matrix and a genotype array
#and initializes a cape object

initialize.cape <- function(pheno, geno){

    data.obj <- list()
    data.obj$pheno <- pheno
    data.obj

}