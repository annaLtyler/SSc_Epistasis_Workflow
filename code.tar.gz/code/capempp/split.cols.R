#Given a vector of colors, for example, and a final length
#This function fills a vector of the final length with the
#colors, such that they are relatively evenly distributed

split.cols <- function(color.v, final.length){
	
	
	
	
	
}