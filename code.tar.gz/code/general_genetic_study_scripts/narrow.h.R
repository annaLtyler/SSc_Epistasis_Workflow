#trait heritability
# pheno <- as.data.frame(sub.key)

heritability <- function(pheno, geno){

	

	
}